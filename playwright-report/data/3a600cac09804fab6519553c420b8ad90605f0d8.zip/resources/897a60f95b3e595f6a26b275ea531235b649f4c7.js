(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/f8d76_@supabase_node-fetch_browser_2469bff5.js",
  "static/chunks/f8d76_094eceff._.js",
  "static/chunks/design-system-advisor_src_9435e47b._.js"
],
    source: "dynamic"
});
