(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f3143f85._.js",
  "static/chunks/f8d76_next_dist_compiled_react-dom_0c641edf._.js",
  "static/chunks/f8d76_next_dist_compiled_next-devtools_index_ebe8e16e.js",
  "static/chunks/f8d76_next_dist_compiled_fd245437._.js",
  "static/chunks/f8d76_next_dist_client_9a8062f0._.js",
  "static/chunks/f8d76_next_dist_789f3ebe._.js",
  "static/chunks/f8d76_@swc_helpers_cjs_d290d023._.js"
],
    source: "entry"
});
